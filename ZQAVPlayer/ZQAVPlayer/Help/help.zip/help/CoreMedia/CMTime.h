
    typedef int64_t CMTimeValue;

    typedef int32_t CMTimeScale;
#define kCMTimeMaxTimescale 0x7fffffffL

    typedef int64_t CMTimeEpoch;

    typedef CF_OPTIONS( uint32_t, CMTimeFlags ) {
        kCMTimeFlags_Valid = 1UL<<0,
        kCMTimeFlags_HasBeenRounded = 1UL<<1,
        kCMTimeFlags_PositiveInfinity = 1UL<<2,
        kCMTimeFlags_NegativeInfinity = 1UL<<3,
        kCMTimeFlags_Indefinite = 1UL<<4,
        kCMTimeFlags_ImpliedValueFlagsMask = kCMTimeFlags_PositiveInfinity | kCMTimeFlags_NegativeInfinity | kCMTimeFlags_Indefinite
    };

    typedef struct {
        CMTimeValue    value;
        CMTimeScale    timescale;
        CMTimeFlags    flags;
        CMTimeEpoch    epoch;
    } CMTime;

#define CMTIME_IS_VALID(time) ((Boolean)(((time).flags & kCMTimeFlags_Valid) != 0))

#define CMTIME_IS_INVALID(time) (! CMTIME_IS_VALID(time))

#define CMTIME_IS_POSITIVE_INFINITY(time) ((Boolean)(CMTIME_IS_VALID(time) && (((time).flags & kCMTimeFlags_PositiveInfinity) != 0)))

#define CMTIME_IS_NEGATIVE_INFINITY(time) ((Boolean)(CMTIME_IS_VALID(time) && (((time).flags & kCMTimeFlags_NegativeInfinity) != 0)))

#define CMTIME_IS_INDEFINITE(time) ((Boolean)(CMTIME_IS_VALID(time) && (((time).flags & kCMTimeFlags_Indefinite) != 0)))

#define CMTIME_IS_NUMERIC(time) ((Boolean)(((time).flags & (kCMTimeFlags_Valid | kCMTimeFlags_ImpliedValueFlagsMask)) == kCMTimeFlags_Valid))

#define CMTIME_HAS_BEEN_ROUNDED(time) ((Boolean)(CMTIME_IS_NUMERIC(time) && (((time).flags & kCMTimeFlags_HasBeenRounded) != 0)))
    
    
CM_EXPORT const CMTime kCMTimeInvalid  ;
CM_EXPORT const CMTime kCMTimeIndefinite  ;
CM_EXPORT const CMTime kCMTimePositiveInfinity  ;
CM_EXPORT const CMTime kCMTimeNegativeInfinity ;
CM_EXPORT const CMTime kCMTimeZero   ;

    CM_EXPORT
    CMTime CMTimeMake(
                      int64_t value,
                      int32_t timescale)    ;
    

    CM_EXPORT
    CMTime CMTimeMakeWithEpoch(
                               int64_t value,        /*! @param value Initializes the value field of the resulting CMTime. */
                               int32_t timescale,    /*! @param timescale Initializes the scale field of the resulting CMTime. */
                               int64_t epoch)        /*! @param epoch Initializes the epoch field of the resulting CMTime. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    CMTime CMTimeMakeWithSeconds(
                                 Float64 seconds,
                                 int32_t preferredTimescale)
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    Float64 CMTimeGetSeconds(
                             CMTime time)
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    typedef CF_ENUM( uint32_t, CMTimeRoundingMethod ) {
        kCMTimeRoundingMethod_RoundHalfAwayFromZero = 1,
        kCMTimeRoundingMethod_RoundTowardZero = 2,
        kCMTimeRoundingMethod_RoundAwayFromZero = 3,
        kCMTimeRoundingMethod_QuickTime = 4,
        kCMTimeRoundingMethod_RoundTowardPositiveInfinity = 5,
        kCMTimeRoundingMethod_RoundTowardNegativeInfinity = 6,
        
        kCMTimeRoundingMethod_Default = kCMTimeRoundingMethod_RoundHalfAwayFromZero
    };
    
    CM_EXPORT
    CMTime CMTimeConvertScale(
                              CMTime time,                    /*! @param time        Source CMTime. */
                              int32_t newTimescale,            /*! @param newTimescale    The requested timescale for the converted result CMTime. */
                              CMTimeRoundingMethod method)    /*! @param method    The requested rounding method. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    CMTime CMTimeAdd(
                     CMTime addend1,                /*! @param addend1            A CMTime to be added. */
                     CMTime addend2)                /*! @param addend2            Another CMTime to be added. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);
    
        CM_EXPORT
    CMTime CMTimeSubtract(
                          CMTime minuend,        /*! @param minuend        The CMTime from which the subtrahend will be subtracted. */
                          CMTime subtrahend)    /*! @param subtrahend    The CMTime that will be subtracted from the minuend. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    CMTime CMTimeMultiply(
                          CMTime time,            /*! @param time            The CMTime that will be multiplied. */
                          int32_t multiplier)        /*! @param multiplier    The integer it will be multiplied by. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    CMTime CMTimeMultiplyByFloat64(
                                   CMTime time,            /*! @param time            The CMTime that will be multiplied. */
                                   Float64 multiplier)        /*! @param multiplier    The Float64 it will be multiplied by. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    CMTime CMTimeMultiplyByRatio(
                                 CMTime time,            /*! @param time            The CMTime to be multiplied then divided. */
                                 int32_t multiplier,        /*! @param multiplier    The value by which to multiply. */
                                 int32_t divisor)        /*! @param divisor    The value by which to divide. */
    __OSX_AVAILABLE_STARTING(__MAC_10_10,__IPHONE_7_1);

    CM_EXPORT
    int32_t CMTimeCompare(
                          CMTime time1,        /*! @param time1 First CMTime in comparison. */
                          CMTime time2)        /*! @param time2 Second CMTime in comparison. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

#define CMTIME_COMPARE_INLINE(time1, comparator, time2) ((Boolean)(CMTimeCompare(time1, time2) comparator 0))

    CM_EXPORT
    CMTime CMTimeMinimum(
                         CMTime time1,    /*! @param time1 A CMTime */
                         CMTime time2)    /*! @param time2 Another CMTime */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    CMTime CMTimeMaximum(
                         CMTime time1,    /*! @param time1 A CMTime */
                         CMTime time2)    /*! @param time2 Another CMTime */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    CMTime CMTimeAbsoluteValue(
                               CMTime time)    /*! @param time A CMTime */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    CFDictionaryRef CM_NULLABLE CMTimeCopyAsDictionary(
                                                       CMTime time,                            /*! @param time            CMTime from which to create dictionary. */
                                                       CFAllocatorRef CM_NULLABLE allocator)    /*! @param allocator    CFAllocator with which to create dictionary.
                                                                                                 Pass kCFAllocatorDefault to use the default
                                                                                                 allocator. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT
    CMTime CMTimeMakeFromDictionary(
                                    CFDictionaryRef CM_NULLABLE dict)    /*! @param dict CFDictionary from which to create CMTime. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);
    
    CM_ASSUME_NONNULL_BEGIN

    CM_EXPORT const CFStringRef kCMTimeValueKey
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT const CFStringRef kCMTimeScaleKey
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT const CFStringRef kCMTimeEpochKey
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);

    CM_EXPORT const CFStringRef kCMTimeFlagsKey
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);
    
    CM_ASSUME_NONNULL_END

    CM_EXPORT
    CFStringRef CM_NULLABLE CMTimeCopyDescription(
                                                  CFAllocatorRef CM_NULLABLE allocator,                /*! @param allocator    CFAllocator with which to create description. Pass
                                                                                                        kCFAllocatorDefault to use the default allocator. */
                                                  CMTime time)                                        /*! @param time            CMTime to describe. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);
    

    CM_EXPORT
    void CMTimeShow(
                    CMTime time)                    /*! @param time            CMTime to show. */
    __OSX_AVAILABLE_STARTING(__MAC_10_7,__IPHONE_4_0);
    
    CF_IMPLICIT_BRIDGING_DISABLED

