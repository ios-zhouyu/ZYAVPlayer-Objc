
//播放状态
typedef NS_ENUM(NSInteger, AVPlayerStatus) {
    AVPlayerStatusUnknown,
    AVPlayerStatusReadyToPlay,
    AVPlayerStatusFailed
};

@interface AVPlayer : NSObject{
@private
    AVPlayerInternal     *_player;
}

+ (instancetype)playerWithURL:(NSURL *)URL;

+ (instancetype)playerWithPlayerItem:(nullable AVPlayerItem *)item;

- (instancetype)initWithURL:(NSURL *)URL;

- (instancetype)initWithPlayerItem:(nullable AVPlayerItem *)item;

@property (nonatomic, readonly) AVPlayerStatus status;

@property (nonatomic, readonly, nullable) NSError *error;

@end


@interface AVPlayer (AVPlayerPlaybackControl)

@property (nonatomic) float rate;

- (void)play;

- (void)pause;

typedef NS_ENUM(NSInteger, AVPlayerTimeControlStatus) {
    AVPlayerTimeControlStatusPaused,
    AVPlayerTimeControlStatusWaitingToPlayAtSpecifiedRate,
    AVPlayerTimeControlStatusPlaying
} NS_ENUM_AVAILABLE(10_12, 10_0);

@property (nonatomic, readonly) AVPlayerTimeControlStatus timeControlStatus NS_AVAILABLE(10_12, 10_0);

typedef NSString * AVPlayerWaitingReason NS_STRING_ENUM;

AVF_EXPORT AVPlayerWaitingReason const AVPlayerWaitingToMinimizeStallsReason NS_AVAILABLE(10_12, 10_0);
AVF_EXPORT AVPlayerWaitingReason const AVPlayerWaitingWhileEvaluatingBufferingRateReason NS_AVAILABLE(10_12, 10_0);
AVF_EXPORT AVPlayerWaitingReason const AVPlayerWaitingWithNoItemToPlayReason NS_AVAILABLE(10_12, 10_0);

@property (nonatomic, readonly, nullable) AVPlayerWaitingReason reasonForWaitingToPlay NS_AVAILABLE(10_12, 10_0);

- (void)playImmediatelyAtRate:(float)rate NS_AVAILABLE(10_12, 10_0);

@end


@interface AVPlayer (AVPlayerItemControl)

@property (nonatomic, readonly, nullable) AVPlayerItem *currentItem;

- (void)replaceCurrentItemWithPlayerItem:(nullable AVPlayerItem *)item;

typedef NS_ENUM(NSInteger, AVPlayerActionAtItemEnd)
{
    AVPlayerActionAtItemEndAdvance    = 0,
    AVPlayerActionAtItemEndPause    = 1,
    AVPlayerActionAtItemEndNone        = 2,
};

@property (nonatomic) AVPlayerActionAtItemEnd actionAtItemEnd;

@end


@interface AVPlayer (AVPlayerTimeControl)

- (CMTime)currentTime;

- (void)seekToDate:(NSDate *)date;

- (void)seekToDate:(NSDate *)date completionHandler:(void (^)(BOOL finished))completionHandler ;

- (void)seekToTime:(CMTime)time;

- (void)seekToTime:(CMTime)time toleranceBefore:(CMTime)toleranceBefore toleranceAfter:(CMTime)toleranceAfter;

- (void)seekToTime:(CMTime)time completionHandler:(void (^)(BOOL finished))completionHandler ;

- (void)seekToTime:(CMTime)time toleranceBefore:(CMTime)toleranceBefore toleranceAfter:(CMTime)toleranceAfter completionHandler:(void (^)(BOOL finished))completionHandler ;

@end


@interface AVPlayer (AVPlayerAdvancedRateControl)

@property (nonatomic) BOOL automaticallyWaitsToMinimizeStalling NS_AVAILABLE(10_12, 10_0);

- (void)setRate:(float)rate time:(CMTime)itemTime atHostTime:(CMTime)hostClockTime ;

- (void)prerollAtRate:(float)rate completionHandler:(nullable void (^)(BOOL finished))completionHandler ;

- (void)cancelPendingPrerolls ;

@property (nonatomic, retain, nullable) __attribute__((NSObject)) CMClockRef masterClock ;

@end


@interface AVPlayer (AVPlayerTimeObservation)

- (id)addPeriodicTimeObserverForInterval:(CMTime)interval queue:(nullable dispatch_queue_t)queue usingBlock:(void (^)(CMTime time))block;

- (id)addBoundaryTimeObserverForTimes:(NSArray<NSValue *> *)times queue:(nullable dispatch_queue_t)queue usingBlock:(void (^)(void))block;

- (void)removeTimeObserver:(id)observer;

@end


@interface AVPlayer (AVPlayerMediaControl)

@property (nonatomic) float volume ;

@property (nonatomic, getter=isMuted) BOOL muted ;

@end


@class AVPlayerMediaSelectionCriteria;

@interface AVPlayer (AVPlayerAutomaticMediaSelection)


@property (nonatomic) BOOL appliesMediaSelectionCriteriaAutomatically ;


- (void)setMediaSelectionCriteria:(nullable AVPlayerMediaSelectionCriteria *)criteria forMediaCharacteristic:(AVMediaCharacteristic)mediaCharacteristic ;

- (nullable AVPlayerMediaSelectionCriteria *)mediaSelectionCriteriaForMediaCharacteristic:(AVMediaCharacteristic)mediaCharacteristic ;

@end


@interface AVPlayer (AVPlayerAudioDeviceSupport)

@property (nonatomic, copy, nullable) NSString *audioOutputDeviceUniqueID NS_AVAILABLE_MAC(10_9);

@end

@interface AVPlayer (AVPlayerExternalPlaybackSupport)

@property (nonatomic) BOOL allowsExternalPlayback ;
@property (nonatomic, readonly, getter=isExternalPlaybackActive) BOOL externalPlaybackActive ;
@property (nonatomic) BOOL usesExternalPlaybackWhileExternalScreenIsActive ;

@property (nonatomic, copy) AVLayerVideoGravity externalPlaybackVideoGravity ;

@end

#if TARGET_OS_IPHONE

@interface AVPlayer (AVPlayerAirPlaySupport)

@property (nonatomic) BOOL allowsAirPlayVideo ;

@property (nonatomic, readonly, getter=isAirPlayVideoActive) BOOL airPlayVideoActive ;

@property (nonatomic) BOOL usesAirPlayVideoWhileAirPlayScreenIsActive ;

@end

#endif // TARGET_OS_IPHONE


@interface AVPlayer (AVPlayerProtectedContent)

@property (nonatomic, readonly) BOOL outputObscuredDueToInsufficientExternalProtection ;

@end

typedef NS_OPTIONS(NSInteger, AVPlayerHDRMode) {
    AVPlayerHDRModeHLG                = 0x1,
    AVPlayerHDRModeHDR10                = 0x2,
    AVPlayerHDRModeDolbyVision        = 0x4,
} API_AVAILABLE(ios(11.2), tvos(11.2)) API_UNAVAILABLE(macos, watchos);

@interface AVPlayer (AVPlayerPlaybackCapabilities)

@property (class, nonatomic, readonly) AVPlayerHDRMode availableHDRModes API_AVAILABLE(ios(11.2), tvos(11.2)) API_UNAVAILABLE(macos, watchos);

API_AVAILABLE(ios(11.2), tvos(11.2)) API_UNAVAILABLE(macos, watchos)
AVF_EXPORT NSNotificationName const AVPlayerAvailableHDRModesDidChangeNotification;

@end

@interface AVPlayer (AVPlayerVideoDecoderGPUSupport)

@property (nonatomic) uint64_t preferredVideoDecoderGPURegistryID API_AVAILABLE(macos(10.13)) API_UNAVAILABLE(ios, tvos, watchos);

@end

@interface AVPlayer (AVPlayerDeprecated)


@property (nonatomic, getter=isClosedCaptionDisplayEnabled) BOOL closedCaptionDisplayEnabled NS_DEPRECATED(10_7, 10_13, 4_0, 11_0, "Allow AVPlayer to enable closed captions automatically according to user preferences by ensuring that the value of appliesMediaSelectionCriteriaAutomatically is YES.");

@end

@class AVQueuePlayerInternal;

@interface AVQueuePlayer : AVPlayer{
@private
    AVQueuePlayerInternal   *_queuePlayer;
}

+ (instancetype)queuePlayerWithItems:(NSArray<AVPlayerItem *> *)items;

- (AVQueuePlayer *)initWithItems:(NSArray<AVPlayerItem *> *)items;

- (NSArray<AVPlayerItem *> *)items;

- (void)advanceToNextItem;

- (BOOL)canInsertItem:(AVPlayerItem *)item afterItem:(nullable AVPlayerItem *)afterItem;

- (void)insertItem:(AVPlayerItem *)item afterItem:(nullable AVPlayerItem *)afterItem;

- (void)removeItem:(AVPlayerItem *)item;

- (void)removeAllItems;

@end

