
AVF_EXPORT NSString *const AVPlayerItemTimeJumpedNotification;
AVF_EXPORT NSString *const AVPlayerItemDidPlayToEndTimeNotification ;
AVF_EXPORT NSString *const AVPlayerItemFailedToPlayToEndTimeNotification ;
AVF_EXPORT NSString *const AVPlayerItemPlaybackStalledNotification       ;
AVF_EXPORT NSString *const AVPlayerItemNewAccessLogEntryNotification     ;
AVF_EXPORT NSString *const AVPlayerItemNewErrorLogEntryNotification        ;
AVF_EXPORT NSString *const AVPlayerItemFailedToPlayToEndTimeErrorKey    ;

typedef NS_ENUM(NSInteger, AVPlayerItemStatus) {
    AVPlayerItemStatusUnknown,
    AVPlayerItemStatusReadyToPlay,
    AVPlayerItemStatusFailed
};

@interface AVPlayerItem : NSObject <NSCopying>{
@private
    AVPlayerItemInternal* _playerItem;
}

+ (instancetype)playerItemWithURL:(NSURL *)URL;

+ (instancetype)playerItemWithAsset:(AVAsset *)asset;

+ (instancetype)playerItemWithAsset:(AVAsset *)asset automaticallyLoadedAssetKeys:(nullable NSArray<NSString *> *)automaticallyLoadedAssetKeys ;

- (instancetype)initWithURL:(NSURL *)URL;

- (instancetype)initWithAsset:(AVAsset *)asset;

- (instancetype)initWithAsset:(AVAsset *)asset automaticallyLoadedAssetKeys:(nullable NSArray<NSString *> *)automaticallyLoadedAssetKeys ;

@property (nonatomic, readonly) AVPlayerItemStatus status;

@property (nonatomic, readonly, nullable) NSError *error;

@end


@class AVPlayerItemTrack;
@class AVMetadataItem;

@interface AVPlayerItem (AVPlayerItemInspection)

@property (nonatomic, readonly) AVAsset *asset;

@property (nonatomic, readonly) NSArray<AVPlayerItemTrack *> *tracks;

@property (nonatomic, readonly) CMTime duration NS_AVAILABLE(10_7, 4_3);

@property (nonatomic, readonly) CGSize presentationSize;

@property (nonatomic, readonly, nullable) NSArray<AVMetadataItem *> *timedMetadata;

@property (nonatomic, readonly) NSArray<NSString *> *automaticallyLoadedAssetKeys NS_AVAILABLE(10_9, 7_0);

@end


@interface AVPlayerItem (AVPlayerItemRateAndSteppingSupport)

@property (nonatomic, readonly) BOOL canPlayFastForward ;
@property (nonatomic, readonly) BOOL canPlaySlowForward ;
@property (nonatomic, readonly) BOOL canPlayReverse ;
@property (nonatomic, readonly) BOOL canPlaySlowReverse;
@property (nonatomic, readonly) BOOL canPlayFastReverse ;
@property (nonatomic, readonly) BOOL canStepForward ;
@property (nonatomic, readonly) BOOL canStepBackward ;
@end


@interface AVPlayerItem (AVPlayerItemTimeControl)

- (CMTime)currentTime;

@property (nonatomic) CMTime forwardPlaybackEndTime;

@property (nonatomic) CMTime reversePlaybackEndTime;

@property (nonatomic, readonly) NSArray<NSValue *> *seekableTimeRanges;

- (void)seekToTime:(CMTime)time completionHandler:(void (^_Nullable)(BOOL finished))completionHandler ;
- (void)seekToTime:(CMTime)time toleranceBefore:(CMTime)toleranceBefore toleranceAfter:(CMTime)toleranceAfter completionHandler:(void (^_Nullable)(BOOL finished))completionHandler ;

- (void)cancelPendingSeeks ;

- (nullable NSDate *)currentDate;

- (BOOL)seekToDate:(NSDate *)date completionHandler:(void (^_Nullable)(BOOL finished))completionHandler ;

- (void)stepByCount:(NSInteger)stepCount;

@property (nonatomic, readonly, nullable) __attribute__((NSObject)) CMTimebaseRef timebase NS_AVAILABLE(10_8, 6_0);

@end


@class AVTextStyleRule;

@interface AVPlayerItem (AVPlayerItemVisualPresentation)

@property (nonatomic, copy, nullable) AVVideoComposition *videoComposition;

@property (nonatomic, readonly, nullable) id<AVVideoCompositing> customVideoCompositor ;

@property (nonatomic) BOOL seekingWaitsForVideoCompositionRendering ;

@property (nonatomic, copy, nullable) NSArray<AVTextStyleRule *> *textStyleRules ;

@property (nonatomic, copy) AVVideoApertureMode videoApertureMode API_AVAILABLE(macos(10.13), ios(11.0), tvos(11.0)) __WATCHOS_PROHIBITED;

@end


@interface AVPlayerItem (AVPlayerItemAudioProcessing)

@property (nonatomic, copy) AVAudioTimePitchAlgorithm audioTimePitchAlgorithm ;

@property (nonatomic, copy, nullable) AVAudioMix *audioMix;

@end


@interface AVPlayerItem (AVPlayerItemPlayability)

@property (nonatomic, readonly) NSArray<NSValue *> *loadedTimeRanges;

@property (nonatomic, readonly, getter=isPlaybackLikelyToKeepUp) BOOL playbackLikelyToKeepUp;

@property (nonatomic, readonly, getter=isPlaybackBufferFull) BOOL playbackBufferFull;
@property (nonatomic, readonly, getter=isPlaybackBufferEmpty) BOOL playbackBufferEmpty;

@property (nonatomic, assign) BOOL canUseNetworkResourcesForLiveStreamingWhilePaused NS_AVAILABLE(10_11, 9_0);

@property (nonatomic) NSTimeInterval preferredForwardBufferDuration NS_AVAILABLE(10_12, 10_0);

@end


@interface AVPlayerItem (AVPlayerItemVariantControl)

@property (nonatomic) double preferredPeakBitRate ;

@property (nonatomic) CGSize preferredMaximumResolution NS_AVAILABLE(10_13, 11_0);

@end


@interface AVPlayerItem (AVPlayerItemMediaSelection)


- (void)selectMediaOption:(nullable AVMediaSelectionOption *)mediaSelectionOption inMediaSelectionGroup:(AVMediaSelectionGroup *)mediaSelectionGroup ;

- (void)selectMediaOptionAutomaticallyInMediaSelectionGroup:(AVMediaSelectionGroup *)mediaSelectionGroup ;

@property (nonatomic, readonly) AVMediaSelection *currentMediaSelection NS_AVAILABLE(10_11, 9_0);

@end

@interface AVPlayerItem (AVPlayerItemLogging)

- (nullable AVPlayerItemAccessLog *)accessLog;

- (nullable AVPlayerItemErrorLog *)errorLog;

@end

@class AVPlayerItemOutput;

@interface AVPlayerItem (AVPlayerItemOutputs)

- (void)addOutput:(AVPlayerItemOutput *)output NS_AVAILABLE(10_8, 6_0);

- (void)removeOutput:(AVPlayerItemOutput *)output NS_AVAILABLE(10_8, 6_0);
@property (nonatomic, readonly) NSArray<AVPlayerItemOutput *> *outputs NS_AVAILABLE(10_8, 6_0);

@end

@class AVPlayerItemMediaDataCollector;

@interface AVPlayerItem (AVPlayerItemMediaDataCollectors)

- (void)addMediaDataCollector:(AVPlayerItemMediaDataCollector *)collector NS_AVAILABLE(10_11_3, 9_3);

- (void)removeMediaDataCollector:(AVPlayerItemMediaDataCollector *)collector NS_AVAILABLE(10_11_3, 9_3);

@property (nonatomic, readonly) NSArray<AVPlayerItemMediaDataCollector *> *mediaDataCollectors NS_AVAILABLE(10_11_3, 9_3);;

@end

@interface AVPlayerItem (AVPlayerItemDeprecated)

- (void)seekToTime:(CMTime)time NS_DEPRECATED(10_7, 10_13, 4_0, 11_0, "Use -seekToTime:completionHandler:, passing nil for the completionHandler if you don't require notification of completion");

- (void)seekToTime:(CMTime)time toleranceBefore:(CMTime)toleranceBefore toleranceAfter:(CMTime)toleranceAfter NS_DEPRECATED(10_7, 10_13, 4_0, 11_0, "Use -seekToTime:toleranceBefore:toleranceAfter:completionHandler:, passing nil for the completionHandler if you don't require notification of completion");

- (BOOL)seekToDate:(NSDate *)date NS_DEPRECATED(10_7, 10_13, 4_0, 11_0, "Use -seekToDate:completionHandler:, passing nil for the completionHandler if you don't require notification of completion");

- (nullable AVMediaSelectionOption *)selectedMediaOptionInMediaSelectionGroup:(AVMediaSelectionGroup *)mediaSelectionGroup NS_DEPRECATED(10_8, 10_13, 5_0, 11_0, "Use currentMediaSelection to obtain an instance of AVMediaSelection, which encompasses the currently selected AVMediaSelectionOption in each of the available AVMediaSelectionGroups");

@end

@class AVPlayerItemAccessLogEvent;

NS_CLASS_AVAILABLE(10_7, 4_3)
@interface AVPlayerItemAccessLog : NSObject <NSCopying>
{
@private
    AVPlayerItemAccessLogInternal    *_playerItemAccessLog;
}
AV_INIT_UNAVAILABLE

- (nullable NSData *)extendedLogData;

@property (nonatomic, readonly) NSStringEncoding extendedLogDataStringEncoding;

@property (nonatomic, readonly) NSArray<AVPlayerItemAccessLogEvent *> *events;

@end

@class AVPlayerItemErrorLogEvent;

NS_CLASS_AVAILABLE(10_7, 4_3)
@interface AVPlayerItemErrorLog : NSObject <NSCopying>{
@private
    AVPlayerItemErrorLogInternal    *_playerItemErrorLog;
}
AV_INIT_UNAVAILABLE

- (nullable NSData *)extendedLogData;

@property (nonatomic, readonly) NSStringEncoding extendedLogDataStringEncoding;

@property (nonatomic, readonly) NSArray<AVPlayerItemErrorLogEvent *> *events;

@end


NS_CLASS_AVAILABLE(10_7, 4_3)
@interface AVPlayerItemAccessLogEvent : NSObject <NSCopying>
{
@private
    AVPlayerItemAccessLogEventInternal    *_playerItemAccessLogEvent;
}
AV_INIT_UNAVAILABLE

@property (nonatomic, readonly) NSInteger numberOfSegmentsDownloaded NS_DEPRECATED(10_7, 10_9, 4_3, 7_0);

@property (nonatomic, readonly) NSInteger numberOfMediaRequests NS_AVAILABLE(10_9, 6_0);

@property (nonatomic, readonly, nullable) NSDate *playbackStartDate;

@property (nonatomic, readonly, nullable) NSString *URI;

@property (nonatomic, readonly, nullable) NSString *serverAddress;

@property (nonatomic, readonly) NSInteger numberOfServerAddressChanges;

@property (nonatomic, readonly, nullable) NSString *playbackSessionID;

@property (nonatomic, readonly) NSTimeInterval playbackStartOffset;

@property (nonatomic, readonly) NSTimeInterval segmentsDownloadedDuration;

@property (nonatomic, readonly) NSTimeInterval durationWatched;

@property (nonatomic, readonly) NSInteger numberOfStalls;

@property (nonatomic, readonly) long long numberOfBytesTransferred;

@property (nonatomic, readonly) NSTimeInterval transferDuration NS_AVAILABLE(10_9, 7_0);

@property (nonatomic, readonly) double observedBitrate;

@property (nonatomic, readonly) double indicatedBitrate;

@property (nonatomic, readonly) double indicatedAverageBitrate NS_AVAILABLE(10_12, 10_0);

@property (nonatomic, readonly) double averageVideoBitrate NS_AVAILABLE(10_12, 10_0);

@property (nonatomic, readonly) double averageAudioBitrate NS_AVAILABLE(10_12, 10_0);

@property (nonatomic, readonly) NSInteger numberOfDroppedVideoFrames;

@property (nonatomic, readonly) NSTimeInterval startupTime NS_AVAILABLE(10_9, 7_0);

@property (nonatomic, readonly) NSInteger downloadOverdue NS_AVAILABLE(10_9, 7_0);

@property (nonatomic, readonly) double observedMaxBitrate NS_AVAILABLE(10_9, 7_0);

@property (nonatomic, readonly) double observedMinBitrate NS_AVAILABLE(10_9, 7_0);

@property (nonatomic, readonly) double observedBitrateStandardDeviation NS_AVAILABLE(10_9, 7_0);

@property (nonatomic, readonly, nullable) NSString *playbackType NS_AVAILABLE(10_9, 7_0);

@property (nonatomic, readonly) NSInteger mediaRequestsWWAN NS_AVAILABLE(10_9, 7_0);

@property (nonatomic, readonly) double switchBitrate NS_AVAILABLE(10_9, 7_0);

@end

NS_CLASS_AVAILABLE(10_7, 4_3)
@interface AVPlayerItemErrorLogEvent : NSObject <NSCopying>
{
@private
    AVPlayerItemErrorLogEventInternal    *_playerItemErrorLogEvent;
}
AV_INIT_UNAVAILABLE

@property (nonatomic, readonly, nullable) NSDate *date;

@property (nonatomic, readonly, nullable) NSString *URI;

@property (nonatomic, readonly, nullable) NSString *serverAddress;

@property (nonatomic, readonly, nullable) NSString *playbackSessionID;

@property (nonatomic, readonly) NSInteger errorStatusCode;

@property (nonatomic, readonly) NSString *errorDomain;

@property (nonatomic, readonly, nullable) NSString *errorComment;

@end

NS_ASSUME_NONNULL_END
