
@interface AVAsset : NSObject <NSCopying, AVAsynchronousKeyValueLoading>{
@private
    AVAssetInternal *_asset;
}

+ (instancetype)assetWithURL:(NSURL *)URL;

@property (nonatomic, readonly) CMTime duration;

@property (nonatomic, readonly) float preferredRate;

@property (nonatomic, readonly) float preferredVolume;

@property (nonatomic, readonly) CGAffineTransform preferredTransform;

@property (nonatomic, readonly) CGSize naturalSize ;

@end


@interface AVAsset (AVAssetAsynchronousLoading)

@property (nonatomic, readonly) BOOL providesPreciseDurationAndTiming;

- (void)cancelLoading;

@end


@interface AVAsset (AVAssetReferenceRestrictions)

typedef NS_OPTIONS(NSUInteger, AVAssetReferenceRestrictions) {
    AVAssetReferenceRestrictionForbidNone = 0UL,
    AVAssetReferenceRestrictionForbidRemoteReferenceToLocal = (1UL << 0),
    AVAssetReferenceRestrictionForbidLocalReferenceToRemote = (1UL << 1),
    AVAssetReferenceRestrictionForbidCrossSiteReference = (1UL << 2),
    AVAssetReferenceRestrictionForbidLocalReferenceToLocal = (1UL << 3),
    AVAssetReferenceRestrictionForbidAll = 0xFFFFUL,
};

@property (nonatomic, readonly) AVAssetReferenceRestrictions referenceRestrictions NS_AVAILABLE(10_7, 5_0);

@end


@class AVAssetTrackGroup;

@interface AVAsset (AVAssetTrackInspection)

@property (nonatomic, readonly) NSArray<AVAssetTrack *> *tracks;

- (nullable AVAssetTrack *)trackWithTrackID:(CMPersistentTrackID)trackID;

- (NSArray<AVAssetTrack *> *)tracksWithMediaType:(AVMediaType)mediaType;

- (NSArray<AVAssetTrack *> *)tracksWithMediaCharacteristic:(AVMediaCharacteristic)mediaCharacteristic;

@property (nonatomic, readonly) NSArray<AVAssetTrackGroup *> *trackGroups ;

@end


@interface AVAsset (AVAssetMetadataReading)

@property (nonatomic, readonly, nullable) AVMetadataItem *creationDate ;

@property (nonatomic, readonly, nullable) NSString *lyrics;

@property (nonatomic, readonly) NSArray<AVMetadataItem *> *commonMetadata;

@property (nonatomic, readonly) NSArray<AVMetadataItem *> *metadata ;

@property (nonatomic, readonly) NSArray<AVMetadataFormat> *availableMetadataFormats;

- (NSArray<AVMetadataItem *> *)metadataForFormat:(AVMetadataFormat)format;

@end


@class AVTimedMetadataGroup;

@interface AVAsset (AVAssetChapterInspection)

@property (readonly) NSArray<NSLocale *> *availableChapterLocales ;

- (NSArray<AVTimedMetadataGroup *> *)chapterMetadataGroupsWithTitleLocale:(NSLocale *)locale containingItemsWithCommonKeys:(nullable NSArray<AVMetadataKey> *)commonKeys ;

- (NSArray<AVTimedMetadataGroup *> *)chapterMetadataGroupsBestMatchingPreferredLanguages:(NSArray<NSString *> *)preferredLanguages ;

@end


@class AVMediaSelectionGroup;

@interface AVAsset (AVAssetMediaSelection)

@property (nonatomic, readonly) NSArray<AVMediaCharacteristic> *availableMediaCharacteristicsWithMediaSelectionOptions ;

- (nullable AVMediaSelectionGroup *)mediaSelectionGroupForMediaCharacteristic:(AVMediaCharacteristic)mediaCharacteristic ;

@property (nonatomic, readonly) AVMediaSelection *preferredMediaSelection NS_AVAILABLE(10_11, 9_0);

@property (nonatomic, readonly) NSArray <AVMediaSelection *> *allMediaSelections NS_AVAILABLE(10_13, 11_0);

@end


@interface AVAsset (AVAssetProtectedContent)

@property (nonatomic, readonly) BOOL hasProtectedContent ;

@end


@interface AVAsset (AVAssetFragments)

@property (nonatomic, readonly) BOOL canContainFragments NS_AVAILABLE(10_11, 9_0);

@property (nonatomic, readonly) BOOL containsFragments NS_AVAILABLE(10_11, 9_0);

@property (nonatomic, readonly) CMTime overallDurationHint NS_AVAILABLE(10_12_2, 10_2);

@end


@interface AVAsset (AVAssetUsability)

@property (nonatomic, readonly, getter=isPlayable) BOOL playable NS_AVAILABLE(10_7, 4_3);

@property (nonatomic, readonly, getter=isExportable) BOOL exportable NS_AVAILABLE(10_7, 4_3);

@property (nonatomic, readonly, getter=isReadable) BOOL readable NS_AVAILABLE(10_7, 4_3);

@property (nonatomic, readonly, getter=isComposable) BOOL composable NS_AVAILABLE(10_7, 4_3);

@property (nonatomic, readonly, getter=isCompatibleWithSavedPhotosAlbum) BOOL compatibleWithSavedPhotosAlbum ;

@property (nonatomic, readonly, getter=isCompatibleWithAirPlayVideo) BOOL compatibleWithAirPlayVideo NS_AVAILABLE(10_11, 9_0);

@end

AVF_EXPORT NSString *const AVURLAssetPreferPreciseDurationAndTimingKey ;

AVF_EXPORT NSString *const AVURLAssetReferenceRestrictionsKey ;

AVF_EXPORT NSString *const AVURLAssetHTTPCookiesKey ;

AVF_EXPORT NSString *const AVURLAssetAllowsCellularAccessKey NS_AVAILABLE_IOS(10_0);

@class AVURLAssetInternal;

@interface AVURLAsset : AVAsset{
@private
    AVURLAssetInternal *_URLAsset;
}

+ (NSArray<AVFileType> *)audiovisualTypes ;

+ (NSArray<NSString *> *)audiovisualMIMETypes ;

+ (BOOL)isPlayableExtendedMIMEType: (NSString *)extendedMIMEType ;

+ (instancetype)URLAssetWithURL:(NSURL *)URL options:(nullable NSDictionary<NSString *, id> *)options;

- (instancetype)initWithURL:(NSURL *)URL options:(nullable NSDictionary<NSString *, id> *)options NS_DESIGNATED_INITIALIZER;

@property (nonatomic, readonly, copy) NSURL *URL;

@end


@class AVAssetResourceLoader;

@interface AVURLAsset (AVURLAssetURLHandling)

@property (nonatomic, readonly) AVAssetResourceLoader *resourceLoader ;

@end

@class AVAssetCache;

@interface AVURLAsset (AVURLAssetCache)

@property (nonatomic, readonly, nullable) AVAssetCache *assetCache NS_AVAILABLE(10_12, 10_0);

@end

@interface AVURLAsset (AVAssetCompositionUtility )

- (nullable AVAssetTrack *)compatibleTrackForCompositionTrack:(AVCompositionTrack *)compositionTrack;

@end

AVF_EXPORT NSString *const AVAssetDurationDidChangeNotification NS_AVAILABLE(10_11, 9_0);

AVF_EXPORT NSString *const AVAssetContainsFragmentsDidChangeNotification NS_AVAILABLE_MAC(10_11);

AVF_EXPORT NSString *const AVAssetWasDefragmentedNotification NS_AVAILABLE_MAC(10_11);

AVF_EXPORT NSString *const AVAssetChapterMetadataGroupsDidChangeNotification NS_AVAILABLE(10_11, 9_0);

AVF_EXPORT NSString *const AVAssetMediaSelectionGroupsDidChangeNotification NS_AVAILABLE(10_11, 9_0);

@protocol AVFragmentMinding

@property (nonatomic, readonly, getter=isAssociatedWithFragmentMinder) BOOL associatedWithFragmentMinder NS_AVAILABLE_MAC(10_11);

@end

@class AVFragmentedAssetInternal;

NS_CLASS_AVAILABLE_MAC(10_11)
@interface AVFragmentedAsset : AVURLAsset <AVFragmentMinding>{
@private
    AVFragmentedAssetInternal    *_fragmentedAsset __attribute__((unused));
}

+ (instancetype)fragmentedAssetWithURL:(NSURL *)URL options:(nullable NSDictionary<NSString *, id> *)options;

@property (nonatomic, readonly) NSArray<AVFragmentedAssetTrack *> *tracks;

@end

@interface AVFragmentedAsset (AVFragmentedAssetTrackInspection)

- (nullable AVFragmentedAssetTrack *)trackWithTrackID:(CMPersistentTrackID)trackID;

- (NSArray<AVFragmentedAssetTrack *> *)tracksWithMediaType:(AVMediaType)mediaType;

- (NSArray<AVFragmentedAssetTrack *> *)tracksWithMediaCharacteristic:(AVMediaCharacteristic)mediaCharacteristic;

@end

@class AVFragmentedAssetMinderInternal;

NS_CLASS_AVAILABLE_MAC(10_11)
@interface AVFragmentedAssetMinder : NSObject{
@private
    AVFragmentedAssetMinderInternal    *_fragmentedAssetMinder;
}

+ (instancetype)fragmentedAssetMinderWithAsset:(AVAsset<AVFragmentMinding> *)asset mindingInterval:(NSTimeInterval)mindingInterval;

@property (nonatomic) NSTimeInterval mindingInterval;

@property (nonatomic, readonly) NSArray<AVAsset<AVFragmentMinding> *> *assets;

- (void)addFragmentedAsset:(AVAsset<AVFragmentMinding> *)asset;

- (void)removeFragmentedAsset:(AVAsset<AVFragmentMinding> *)asset;

@end

@interface AVURLAsset (AVURLAssetContentKeyEligibility) <AVContentKeyRecipient>

@property (nonatomic, readonly) BOOL mayRequireContentKeysForMediaDataProcessing API_AVAILABLE(macos(10.12.4), ios(10.3), tvos(10.2), watchos(3.3));

@end
