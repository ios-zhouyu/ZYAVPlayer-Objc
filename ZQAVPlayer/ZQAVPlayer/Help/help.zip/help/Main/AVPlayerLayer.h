@interface AVPlayerLayer : CALayer{
@private
    AVPlayerLayerInternal        *_playerLayer;
}

+ (AVPlayerLayer *)playerLayerWithPlayer:(nullable AVPlayer *)player;

@property (nonatomic, retain, nullable) AVPlayer *player;

@property(copy) AVLayerVideoGravity videoGravity;

@property(nonatomic, readonly, getter=isReadyForDisplay) BOOL readyForDisplay;

@property (nonatomic, readonly) CGRect videoRect ;

@property (nonatomic, copy, nullable) NSDictionary<NSString *, id> *pixelBufferAttributes NS_AVAILABLE(10_11, 9_0);

@end

